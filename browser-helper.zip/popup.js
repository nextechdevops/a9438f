// Function to update stats from Chrome storage
function updateStats() {
  chrome.storage.local.get(['adsBlocked', 'dataSaved'], (data) => {
    // Update ads blocked count with commas
    const adsBlocked = data.adsBlocked || 0;
    document.getElementById('adsBlocked').textContent = adsBlocked.toLocaleString();
    
    // Update data saved with proper formatting
    const dataSaved = data.dataSaved || 0;
    if (dataSaved > 1048576) { // > 1GB
      document.getElementById('dataSaved').textContent = (dataSaved / 1048576).toFixed(2) + ' GB';
    } else if (dataSaved > 1024) { // > 1MB
      document.getElementById('dataSaved').textContent = (dataSaved / 1024).toFixed(2) + ' MB';
    } else {
      document.getElementById('dataSaved').textContent = dataSaved + ' KB';
    }
    
    // Trackers count - static 18 (matches rules.json)
    document.getElementById('trackers').textContent = '18';
    
    // Optional: Log for debugging (remove in production)
    // console.log('Stats updated:', { adsBlocked, dataSaved });
  });
}

// Initial update when popup opens
document.addEventListener('DOMContentLoaded', updateStats);

// Listen for storage changes and update in real-time
chrome.storage.onChanged.addListener((changes, namespace) => {
  if (namespace === 'local') {
    updateStats();
  }
});

// Update every second while popup is open
setInterval(updateStats, 1000);
