# AdGuard Lite

Lightweight ad blocker that saves bandwidth and blocks trackers.

## Features
- Blocks ads from major networks
- Saves data by preventing ad downloads
- No configuration needed
- Works on all websites

## Stats
- 18+ ad networks blocked
- Real-time blocking counter
- Data savings tracker

## Privacy
No data collection. All blocking happens locally.
